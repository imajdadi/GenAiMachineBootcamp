import calculus
# import pandas as pd 

print(f"le nombre est {calculus.number}")
print("je suis dans le fichier test")

calculus.calculate()




# number = 10

# import calculus

# print(calculus.number)
# print(calculus.calculate())

# from calculus import number as num, calculate #alias

# print(num)
# print(calculate())

x = 1
y = 2
