# - Classe gentils   
#     # attributs des personnages
#     - energy
#     - points
#     - nom
#     - pouvoir

#     # methodes des personnages
#     - battre
#     - explorer
#     - acheter

# - object
#     - Magicien
#         - 100
#         - 1000