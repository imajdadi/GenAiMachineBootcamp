1. Relire les cours de la plateforme
2. Revoir le code du matin
3. Regarder certaines videos qui peuvent vous aider

